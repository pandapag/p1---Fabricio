const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser'); 
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());

mongoose.connect('mongodb+srv://joaovitorfff:1234@cluster0.3bo2jrl.mongodb.net/faab?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Conexão com o MongoDB estabelecida');
}).catch((error) => {
    console.error('Erro ao conectar ao MongoDB:', error);
});

app.use(bodyParser.urlencoded({ extended: true }));

const User = require('./models/User');

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`O servidor está funcionando na porta: ${PORT}`);
});

app.post('/login', async (req, res) => {
    const { email, senha } = req.body;
    console.log("Email:", email);  
    console.log("Senha:", senha);  
    try {
        const user = await mongoose.connection.db.collection('usuarios').findOne({ email: email });
        console.log("Usuário encontrado:", user); 
        if (user && user.senha === senha) {
            res.send("<h1>Login realizado com sucesso!</h1>");
        } else {
            res.status(401).send("<script>alert('Email ou senha incorretos'); window.location.href = '/login';</script>");
        }
    } catch (error) {
        console.error('Erro ao buscar o usuário:', error);
        res.status(500).send("Erro interno do servidor");
    }
});
